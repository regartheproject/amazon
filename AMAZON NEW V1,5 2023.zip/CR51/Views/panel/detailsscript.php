<!DOCTYPE html>
<html lang="zxx">

<head>

    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <title>Admin - CR51 NETWORK</title>
    <link rel="icon" href="<?= base_url() ?>CR51/Assets/Panel/Assets/img/mini_logo.png" type="image/png">

    <link rel="stylesheet" href="<?= base_url() ?>CR51/Assets/Panel/Assets/css/bootstrap1.min.css" />

    <link rel="stylesheet" href="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/themefy_icon/themify-icons.css" />

    <link rel="stylesheet" href="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/niceselect/css/nice-select.css" />

    <link rel="stylesheet" href="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/owl_carousel/css/owl.carousel.css" />

    <link rel="stylesheet" href="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/gijgo/gijgo.min.css" />

    <link rel="stylesheet" href="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/font_awesome/css/all.min.css" />
    <link rel="stylesheet" href="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/tagsinput/tagsinput.css" />

    <link rel="stylesheet" href="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/datepicker/date-picker.css" />
    <link rel="stylesheet" href="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/vectormap-home/vectormap-2.0.2.css" />

    <link rel="stylesheet" href="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/scroll/scrollable.css" />

    <link rel="stylesheet" href="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/datatable/css/jquery.dataTables.min.css" />
    <link rel="stylesheet" href="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/datatable/css/responsive.dataTables.min.css" />
    <link rel="stylesheet" href="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/datatable/css/buttons.dataTables.min.css" />

    <link rel="stylesheet" href="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/text_editor/summernote-bs4.css" />

    <link rel="stylesheet" href="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/morris/morris.css">

    <link rel="stylesheet" href="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/material_icon/material-icons.css" />

    <link rel="stylesheet" href="<?= base_url() ?>CR51/Assets/Panel/Assets/css/metisMenu.css">

    <link rel="stylesheet" href="<?= base_url() ?>CR51/Assets/Panel/Assets/css/style1.css" />
    <link rel="stylesheet" href="<?= base_url() ?>CR51/Assets/Panel/Assets/css/colors/default.css" id="colorSkinCSS">
</head>

<body class="crm_body_bg">
    <?php echo view('panel/menu'); ?>
    <section class="main_content dashboard_part large_header_bg">
        <?php echo view('panel/atas'); ?>
        <div class="main_content_iner overly_inner ">
            <div class="container-fluid p-0 ">
                <div class="row">
                    <div class="col-md-12">
                        <div class="white_card position-relative mb_20">
                            <div class="card-body">
                                <h5 class="mt-0">Details Script</h5>
                                <p class="text-muted mb-3 font_s_14">
                                    # CR51 TIDAK BERTANGUNG JAWAB JIKA ANDA BELI SCRIPT INI BUKAN DARI PIHAK KAMI<br><br>
                                    # KARENA BISA SAJA SCRIPT INI SUDAH DIMODIF OLEH ORANG YANG TIDAK TAHU SIAPA<br><br>
                                    # SCRIPT INI NO ENCRYPT, JADI JANGAN PERNAH BILANG SCRIPT INI LOG KALO BELUM ADA BUKTI TERIMA KASIH<br><br>
                                    # KAMI MEMPERSILAHKAN ANDA MERECODE SCRIPT INI DAN KEMBANGKAN SCRIPT INI LEBIH BAGUS DARI MILIK KAMI ITU LEBIH BAIK<br><br>
                                    # KAMI SANGAT SANGAT BERTIMA KASIH KEPADA ANDA YANG SUDAH PERCAYA KEPADA KAMI<br><br>
                                    # GOOD LUCK BROO, SALAM OWNER TAMVAN</p>

                                <code>
                                    Nama Script : <?= SiNGFO('NAMA'); ?><br>
                                    Version : <?= SiNGFO('VERSION'); ?><br>
                                    Rilis Date : <?= SiNGFO('RILISDATE'); ?><br>
                                    Created By : <?= SiNGFO('CREATEBY'); ?> <br>
                                </code>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        </div>
        <?php echo view('panel/bawah'); ?>
    </section>

    <div id="back-top" style="display: none;">
        <a title="Go to Top" href="#">
            <i class="ti-angle-up"></i>
        </a>
    </div>

    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/js/jquery1-3.4.1.min.js"></script>

    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/js/popper1.min.js"></script>

    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/js/bootstrap1.min.js"></script>

    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/js/metisMenu.js"></script>

    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/count_up/jquery.waypoints.min.js"></script>

    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/chartlist/Chart.min.js"></script>

    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/count_up/jquery.counterup.min.js"></script>

    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/niceselect/js/jquery.nice-select.min.js"></script>

    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/owl_carousel/js/owl.carousel.min.js"></script>

    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/datatable/js/jquery.dataTables.min.js"></script>
    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/datatable/js/dataTables.responsive.min.js"></script>
    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/datatable/js/dataTables.buttons.min.js"></script>
    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/datatable/js/buttons.flash.min.js"></script>
    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/datatable/js/jszip.min.js"></script>
    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/datatable/js/pdfmake.min.js"></script>
    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/datatable/js/vfs_fonts.js"></script>
    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/datatable/js/buttons.html5.min.js"></script>
    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/datatable/js/buttons.print.min.js"></script>

    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/datepicker/datepicker.js"></script>
    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/datepicker/datepicker.en.js"></script>
    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/datepicker/datepicker.custom.js"></script>
    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/js/chart.min.js"></script>
    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/chartjs/roundedBar.min.js"></script>

    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/progressbar/jquery.barfiller.js"></script>

    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/tagsinput/tagsinput.js"></script>

    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/text_editor/summernote-bs4.js"></script>
    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/am_chart/amcharts.js"></script>

    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/scroll/perfect-scrollbar.min.js"></script>
    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/scroll/scrollable-custom.js"></script>

    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/vectormap-home/vectormap-2.0.2.min.js"></script>
    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/vectormap-home/vectormap-world-mill-en.js"></script>

    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/apex_chart/apex-chart2.js"></script>
    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/apex_chart/apex_dashboard.js"></script>
    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/echart/echarts.min.js"></script>
    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/chart_am/core.js"></script>
    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/chart_am/charts.js"></script>
    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/chart_am/animated.js"></script>
    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/chart_am/kelly.js"></script>
    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/chart_am/chart-custom.js"></script>

    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/js/dashboard_init.js"></script>
    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/js/custom.js"></script>
</body>

</html>